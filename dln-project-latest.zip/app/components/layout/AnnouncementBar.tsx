import { useEffect, useState } from "react";
import { supabase } from "../../lib/supabase";

export default function AnnouncementBar() {
  const [message, setMessage] = useState("");
  const [enabled, setEnabled] = useState(false);

  useEffect(() => {
    let mounted = true;

    async function loadAnnouncement() {
      const { data } = await supabase
        .from("site_settings")
        .select("announcement_text, announcement_enabled")
        .eq("id", 1)
        .single();

      if (!mounted) return;

      setMessage((data?.announcement_text?.trim() || "").replace(/(?:❤️|♥|♡)?\s*Wishlist/gi, "").replace(/[❤️♥♡]/g, "").trim());
      setEnabled(data?.announcement_enabled ?? false);
    }

    loadAnnouncement();

    return () => {
      mounted = false;
    };
  }, []);

  if (!enabled || !message) return null;

  return (
    <div className="bg-[var(--teal)] px-4 py-3 text-center text-base font-bold leading-6 text-white sm:text-lg">
      {message}
    </div>
  );
}
